import ipaddress
import uuid
from collections.abc import Sequence
from enum import Enum as PyEnum
from typing import Any, TypeVar, cast, overload

from sqlalchemy.exc import ArgumentError
from sqlalchemy.sql.elements import ColumnElement
from sqlalchemy.types import (
    ARRAY,
    Float,
    Integer,
    Interval,
    Numeric,
    TypeEngine,
    UserDefinedType,
)
from sqlalchemy.types import (
    Boolean as SqlaBoolean,
)
from sqlalchemy.types import (
    Date as SqlaDate,
)
from sqlalchemy.types import (
    DateTime as SqlaDateTime,
)
from sqlalchemy.types import (
    String as SqlaString,
)

from clickhouse_connect.cc_sqlalchemy.datatypes.base import ChSqlaType, schema_types, sqla_type_from_name
from clickhouse_connect.cc_sqlalchemy.sql.clauses import json_subcolumn
from clickhouse_connect.datatypes.base import EMPTY_TYPE_DEF, LC_TYPE_DEF, NULLABLE_TYPE_DEF, TypeDef
from clickhouse_connect.datatypes.numeric import Enum8 as ChEnum8
from clickhouse_connect.datatypes.numeric import Enum16 as ChEnum16
from clickhouse_connect.driver import tzutil
from clickhouse_connect.driver.common import decimal_prec

_T = TypeVar("_T")


class Int8(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt8(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Int16(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt16(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Int32(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt32(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Int64(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt64(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Int128(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt128(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Int256(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class UInt256(ChSqlaType, Integer):  # type: ignore[misc]
    pass


class Float32(ChSqlaType, Float):  # type: ignore[misc]
    def __init__(self, type_def: TypeDef = EMPTY_TYPE_DEF):
        ChSqlaType.__init__(self, type_def)
        Float.__init__(self)


class Float64(ChSqlaType, Float):  # type: ignore[misc]
    def __init__(self, type_def: TypeDef = EMPTY_TYPE_DEF):
        ChSqlaType.__init__(self, type_def)
        Float.__init__(self)


class Bool(ChSqlaType, SqlaBoolean):  # type: ignore[misc]
    def __init__(self, type_def: TypeDef = EMPTY_TYPE_DEF, **kwargs):
        ChSqlaType.__init__(self, type_def)
        SqlaBoolean.__init__(self, **kwargs)


class Boolean(Bool):
    pass


class Decimal(ChSqlaType, Numeric):  # type: ignore[misc]
    dec_size = 0

    def __init__(self, precision: int = 0, scale: int = 0, type_def: TypeDef | None = None):
        """
        Construct either with precision and scale (for DDL), or a TypeDef with those values (by name)
        :param precision:  Number of digits the Decimal
        :param scale: Digits after the decimal point
        :param type_def: Parsed type def from ClickHouse arguments
        """
        if type_def:
            if self.dec_size:
                precision = decimal_prec[self.dec_size]
                scale = type_def.values[0]
            else:
                precision, scale = type_def.values
        elif not precision or scale < 0 or scale > precision:
            raise ArgumentError("Invalid precision or scale for ClickHouse Decimal type")
        else:
            type_def = TypeDef(values=(precision, scale))
        ChSqlaType.__init__(self, type_def)
        Numeric.__init__(self, precision, scale)


class Decimal32(Decimal):
    dec_size = 32


class Decimal64(Decimal):
    dec_size = 64


class Decimal128(Decimal):
    dec_size = 128


class Decimal256(Decimal):
    dec_size = 256


class Enum(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    _size = 16
    python_type = str

    def __init__(
        self,
        enum: type[PyEnum] | None = None,
        keys: Sequence[str] | None = None,
        values: Sequence[int] | None = None,
        type_def: TypeDef | None = None,
    ):
        """
        Construct a ClickHouse enum either from a Python Enum or parallel lists of keys and value.  Note that
        Python enums do not support empty strings as keys, so the alternate keys/values must be used in that case
        :param enum: Python enum to convert
        :param keys: List of string keys
        :param values: List of integer values
        :param type_def: TypeDef from parse_name function
        """
        if not type_def:
            if enum:
                keys = [e.name for e in enum]
                values = [e.value for e in enum]
            if keys is None or values is None:
                raise ArgumentError("Enum requires either a Python enum or both 'keys' and 'values'")
            self._validate(keys, values)
            if self.__class__.__name__ == "Enum":
                if max(values) <= 127 and min(values) >= -128:
                    self._ch_type_cls = ChEnum8
                else:
                    self._ch_type_cls = ChEnum16
            type_def = TypeDef(keys=tuple(keys), values=tuple(values))
        super().__init__(type_def)

    @classmethod
    def _validate(cls, keys: Sequence[str], values: Sequence[int]):
        bad_key = next((x for x in keys if not isinstance(x, str)), None)
        if bad_key:
            raise ArgumentError(f"ClickHouse enum key {bad_key} is not a string")
        bad_value = next((x for x in values if not isinstance(x, int)), None)
        if bad_value:
            raise ArgumentError(f"ClickHouse enum value {bad_value} is not an integer")
        value_min = -(2 ** (cls._size - 1))
        value_max = 2 ** (cls._size - 1) - 1
        bad_value = next((x for x in values if x < value_min or x > value_max), None)
        if bad_value:
            raise ArgumentError(f"Clickhouse enum value {bad_value} is out of range")


class Enum8(Enum):
    _size = 8
    _ch_type_cls = ChEnum8


class Enum16(Enum):
    _ch_type_cls = ChEnum16


class String(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = str


class FixedString(ChSqlaType, SqlaString):  # type: ignore[misc]
    def __init__(self, size: int = -1, type_def: TypeDef | None = None):
        if not type_def:
            type_def = TypeDef(values=(size,))
        ChSqlaType.__init__(self, type_def)
        SqlaString.__init__(self, size)


class IPv4(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = ipaddress.IPv4Address


class IPv6(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = ipaddress.IPv6Address


class UUID(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = uuid.UUID


class Nothing(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = type(None)


class Point(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = tuple


class Ring(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list


class Polygon(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list


class MultiPolygon(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list


class LineString(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list


class MultiLineString(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list


class Date(ChSqlaType, SqlaDate):  # type: ignore[misc]
    pass


class Date32(ChSqlaType, SqlaDate):  # type: ignore[misc]
    pass


_TIMEZONE_SENTINEL = object()


def _resolve_tz_alias(tz, timezone):
    """Resolve `tz=` / `timezone=` alias (clickhouse-sqlalchemy naming). Returns the zone string or None.

    timezone=False maps silently to None: SQLAlchemy's type-adaptation passes it when cloning
    DateTime (inherited from SqlaDateTime.timezone default). timezone=True is rejected because
    ClickHouse requires a concrete IANA zone.
    """
    if timezone is not _TIMEZONE_SENTINEL:
        if timezone is True:
            raise ArgumentError(
                "timezone=True is not supported for ClickHouse DateTime types; "
                "pass a named IANA zone string such as timezone='UTC' or timezone='America/New_York'"
            )
        if timezone is False:
            return tz
        if tz is not None:
            raise ArgumentError("Cannot specify both 'tz' and 'timezone'; they are aliases")
        return timezone
    return tz


class DateTime(ChSqlaType, SqlaDateTime):  # type: ignore[misc]
    def __init__(self, tz: str | None = None, type_def: TypeDef | None = None, timezone=_TIMEZONE_SENTINEL):
        """tz / timezone: IANA zone string (resolved via zoneinfo; install `tzdata` on Windows)."""
        tz = _resolve_tz_alias(tz, timezone)
        if not type_def:
            if tz:
                tzutil.resolve_zone(tz)
                type_def = TypeDef(values=(f"'{tz}'",))
            else:
                type_def = EMPTY_TYPE_DEF
        ChSqlaType.__init__(self, type_def)
        SqlaDateTime.__init__(self)


class DateTime64(ChSqlaType, SqlaDateTime):  # type: ignore[misc]
    def __init__(self, precision: int | None = None, tz: str | None = None, type_def: TypeDef | None = None, timezone=_TIMEZONE_SENTINEL):
        """precision: 3/6/9 for ms/us/ns. tz / timezone: IANA zone string."""
        tz = _resolve_tz_alias(tz, timezone)
        if not type_def:
            if tz:
                tzutil.resolve_zone(tz)
                type_def = TypeDef(values=(precision, f"'{tz}'"))
            else:
                type_def = TypeDef(values=(precision,))
        prec = type_def.values[0] if len(type_def.values) else None
        if not isinstance(prec, int) or prec < 0 or prec > 9:
            raise ArgumentError(f"Invalid precision value {prec} for ClickHouse DateTime64")
        ChSqlaType.__init__(self, type_def)
        SqlaDateTime.__init__(self)


class Time(ChSqlaType, Interval):  # type: ignore[misc]
    """
    Represents the ClickHouse Time type, which corresponds to a timedelta.

    Represents time durations in the range -999:59:59 to 999:59:59 with
    second precision. Maps to Python timedelta objects.
    """

    cache_ok = True

    def __init__(self, type_def: TypeDef = EMPTY_TYPE_DEF):
        ChSqlaType.__init__(self, type_def)
        Interval.__init__(self)

    def bind_processor(self, dialect):
        return None

    def coerce_compared_value(self, op, value):
        return self


class Time64(ChSqlaType, Interval):  # type: ignore[misc]
    """
    Represents the ClickHouse Time64 type with configurable precision.

    Represents time durations in the range -999:59:59.999999999 to
    999:59:59.999999999 configurable precision. Maps to Python timedelta objects.
    If no precision is defined it default to 3.
    """

    cache_ok = True

    def __init__(self, precision: int | None = None, type_def: TypeDef | None = None):
        """
        Time64 constructor with precision if not constructed with TypeDef.
        :param precision: 3 (ms), 6 (us), or 9 (ns) for sub-second precision.
        :param type_def: TypeDef from parse_name function.
        """
        if not type_def:
            if precision is None:
                precision = 3

            if precision not in (3, 6, 9):
                raise ArgumentError(f"Invalid precision value {precision} for ClickHouse Time64. Must be 3, 6, or 9.")
            type_def = TypeDef(values=(precision,))
        else:
            precision = type_def.values[0] if len(type_def.values) > 0 else 3

        ChSqlaType.__init__(self, type_def)

        Interval.__init__(self, second_precision=precision)

    def bind_processor(self, dialect):
        return None

    def coerce_compared_value(self, op, value):
        return self


def Nullable(element: ChSqlaType | type[ChSqlaType]) -> ChSqlaType:  # noqa: N802
    """Wrap a ChSqlaType instance or class with a Nullable modifier for DDL construction."""
    if callable(element):
        return element(type_def=NULLABLE_TYPE_DEF)
    orig = element.type_def
    wrappers = orig if "Nullable" in orig.wrappers else orig.wrappers + ("Nullable",)
    return element.__class__(type_def=TypeDef(wrappers, orig.keys, orig.values))


def LowCardinality(element: ChSqlaType | type[ChSqlaType]) -> ChSqlaType:  # noqa: N802
    """Wrap a ChSqlaType instance or class with a LowCardinality modifier for DDL construction."""
    if callable(element):
        return element(type_def=LC_TYPE_DEF)
    orig = element.type_def
    wrappers = orig if "LowCardinality" in orig.wrappers else ("LowCardinality",) + orig.wrappers
    return element.__class__(type_def=TypeDef(wrappers, orig.keys, orig.values))


class Array(ChSqlaType, ARRAY):  # type: ignore[misc]
    python_type = list
    dimensions = 1

    def __init__(self, element: ChSqlaType | type[ChSqlaType] | None = None, type_def: TypeDef | None = None):
        """
        Array constructor that can take a wrapped Array type if not constructed from a TypeDef
        :param element: ChSqlaType instance or class to wrap
        :param type_def: TypeDef from parse_name function
        """
        if not type_def:
            if callable(element):
                element = element()
            if element is None:
                raise ArgumentError("Array requires an element type or type_def")
            type_def = TypeDef(values=(element.name,))
        ChSqlaType.__init__(self, type_def)
        # Set item_type directly; calling ARRAY.__init__ would reject nested Array(Array(T)),
        # which CH supports natively (CH expresses dimensions via nesting, not a dim count).
        # as_tuple has no class-level default and ARRAY reads it (e.g. the hashable property), so set it
        # here since we skip ARRAY.__init__.
        self.item_type = cast("TypeEngine[Any]", sqla_type_from_name(type_def.values[0]))
        self.as_tuple = False


class Map(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = dict

    def __init__(
        self,
        key_type: ChSqlaType | type[ChSqlaType] | None = None,
        value_type: ChSqlaType | type[ChSqlaType] | None = None,
        type_def: TypeDef | None = None,
    ):
        """
        Map constructor that can take a wrapped key/values types if not constructed from a TypeDef
        :param key_type: ChSqlaType instance or class to use as keys for the Map
        :param value_type: ChSqlaType instance or class to use as values for the Map
        :param type_def: TypeDef from parse_name function
        """
        if not type_def:
            if callable(key_type):
                key_type = key_type()
            if callable(value_type):
                value_type = value_type()
            if key_type is None or value_type is None:
                raise ArgumentError("Map requires key_type and value_type, or type_def")
            type_def = TypeDef(values=(key_type.name, value_type.name))
        super().__init__(type_def)


class Tuple(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = tuple

    def __init__(
        self,
        *args,
        elements: Sequence[ChSqlaType | type[ChSqlaType]] | None = None,
        type_def: TypeDef | None = None,
    ):
        """Tuple(UInt32, UUID) variadic form or Tuple(elements=[UInt32, UUID]) list form, not both."""
        if type_def is None and not args and elements is None:
            # SA's dialect_impl -> adapt -> constructor_copy can call cls() with no args
            # because get_cls_kwargs doesn't see keyword-only args behind *args.
            # adapt() below preserves the real type_def; this branch just avoids a crash.
            type_def = EMPTY_TYPE_DEF
        if not type_def:
            if args and elements is not None:
                raise ArgumentError("Cannot specify both positional elements and the 'elements' kwarg")
            if args:
                elements = args
            values = [et() if callable(et) else et for et in elements]  # type: ignore[union-attr]
            type_def = TypeDef(values=tuple(v.name for v in values))
        super().__init__(type_def)

    def adapt(self, cls, **kw):
        # Bypass SA's constructor_copy: it can't see keyword-only args behind *args and
        # would produce an empty Tuple. Copy state directly.
        inst = cls.__new__(cls)
        inst.__dict__.update(self.__dict__)
        return inst


class JSON(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    cache_ok: bool = True
    python_type: type[dict[str, object]] = dict

    class _Comparator(UserDefinedType.Comparator):  # type: ignore[type-arg]
        """Build storage-backed JSON subcolumn expressions."""

        def __getitem__(self, segment: str) -> ColumnElement[object]:
            return json_subcolumn(self.expr, segment)

        @overload
        def subcolumn(self, segment: str, type_: None = None) -> ColumnElement[object]: ...

        @overload
        def subcolumn(self, segment: str, type_: TypeEngine[_T] | type[TypeEngine[_T]]) -> ColumnElement[_T]: ...

        def subcolumn(
            self,
            segment: str,
            type_: TypeEngine[Any] | type[TypeEngine[Any]] | None = None,
        ) -> ColumnElement[Any]:
            """Select one JSON path segment and optionally cast it."""
            return json_subcolumn(self.expr, segment, type_)

    comparator_factory: type[_Comparator] = _Comparator


class Nested(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    """
    Note this isn't currently supported for insert/select, only table definitions
    """

    python_type = list


class SimpleAggregateFunction(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = str

    def __init__(
        self,
        name: str | None = None,
        element: ChSqlaType | type[ChSqlaType] | None = None,
        type_def: TypeDef | None = None,
    ):
        """
        Constructor that can take the SimpleAggregateFunction name and wrapped type if not constructed from a TypeDef
        :param name: Aggregate function name
        :param element: ChSqlaType instance or class which the function aggregates
        :param type_def: TypeDef from parse_name function
        """
        if not type_def:
            if callable(element):
                element = element()
            if element is None:
                raise ArgumentError("SimpleAggregateFunction requires an element type or type_def")
            type_def = TypeDef(values=(name, element.name))
        super().__init__(type_def)


class AggregateFunction(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    """
    Note this isn't currently supported for insert/select, only table definitions
    """

    python_type = str

    def __init__(self, *params, type_def: TypeDef | None = None):
        """
        Simply wraps the parameters for AggregateFunction for DDL, unless the TypeDef is specified.
        Callables or actual types are converted to their names.
        :param params: AggregateFunction parameters
        :param type_def: TypeDef from parse_name function
        """
        if not type_def:
            values: tuple[Any, ...] = ()
            for x in params:
                if callable(x):
                    x = x()
                if isinstance(x, ChSqlaType):
                    x = x.name
                values += (x,)
            type_def = TypeDef(values=values)
        super().__init__(type_def)


class QBit(ChSqlaType, UserDefinedType):  # type: ignore[misc]
    python_type = list

    def __init__(self, element_type: str | None = None, dimension: int | None = None, type_def: TypeDef | None = None):
        """
        QBit constructor for bit-transposed vector types
        :param element_type: Element type (BFloat16, Float32, or Float64)
        :param dimension: Number of elements in the vector
        :param type_def: TypeDef from parse_name function (used during reflection)
        """
        if not type_def:
            if not element_type or not dimension:
                raise ArgumentError("QBit requires element_type and dimension parameters")
            type_def = TypeDef(values=(element_type, dimension))
        super().__init__(type_def)


__all__ = sorted(schema_types) + ["LowCardinality", "Nullable"]
