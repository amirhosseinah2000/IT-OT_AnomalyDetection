import logging
import re
from collections.abc import Mapping, Sequence
from typing import Any, cast

from clickhouse_connect.datatypes.base import ClickHouseType
from clickhouse_connect.datatypes.registry import get_from_name
from clickhouse_connect.driver import Client
from clickhouse_connect.driver.common import unescape_identifier
from clickhouse_connect.driver.exceptions import DatabaseError, ProgrammingError
from clickhouse_connect.driver.parser import parse_callable
from clickhouse_connect.driver.query import remove_sql_comments

logger = logging.getLogger(__name__)

insert_re = re.compile(r"^\s*INSERT\s+INTO\s+(.*$)", re.IGNORECASE)
str_type = get_from_name("String")
int_type = get_from_name("Int32")
_IMPLICIT_NULLABLE_BASE_TYPES = frozenset(("Dynamic", "Variant"))


def _cursor_null_ok(ch_type: Any) -> bool | None:
    if isinstance(ch_type, str):
        try:
            ch_type = get_from_name(ch_type)
        except (DatabaseError, ValueError, TypeError, IndexError):
            return None
    if not isinstance(ch_type, ClickHouseType):
        return None
    if ch_type.nullable or ch_type.base_type in _IMPLICIT_NULLABLE_BASE_TYPES:
        return True
    if ch_type.base_type == "SimpleAggregateFunction":
        return _cursor_null_ok(getattr(ch_type, "element_type", None))
    return False


def _leading_keyword(sql: str) -> str:
    pos = 0
    length = len(sql)
    while pos < length:
        char = sql[pos]
        if char.isspace():
            pos += 1
            continue
        if sql.startswith("--", pos) or sql.startswith("//", pos) or sql.startswith("#!", pos) or sql.startswith("# ", pos):
            next_line = sql.find("\n", pos + 1)
            if next_line == -1:
                return ""
            pos = next_line + 1
            continue
        if sql.startswith("/*", pos):
            pos += 2
            depth = 1
            while pos < length and depth:
                if sql.startswith("/*", pos):
                    depth += 1
                    pos += 2
                elif sql.startswith("*/", pos):
                    depth -= 1
                    pos += 2
                else:
                    pos += 1
            if depth:
                return ""
            continue
        break
    match = re.match(r"[A-Za-z_]+", sql[pos:])
    return "" if match is None else match.group(0).upper()


class Cursor:
    """
    See :ref:`https://peps.python.org/pep-0249/`
    """

    def __init__(self, client: Client):
        self.client = client
        self.arraysize: int = 1
        self.data: Sequence | None = None
        self.names: Sequence[str] = []
        self.types: Sequence[Any] = []
        self._rowcount: int = 0
        self._summary: list[dict[str, Any]] = []
        self._ix: int = 0

    def check_valid(self) -> None:
        if self.data is None:
            raise ProgrammingError("Cursor is not valid")

    @property
    def description(self) -> list[tuple[str, Any, None, None, None, None, bool | None]]:
        return [(n, t, None, None, None, None, _cursor_null_ok(t)) for n, t in zip(self.names, self.types)]

    @property
    def rowcount(self) -> int:
        return self._rowcount

    @property
    def summary(self) -> list[dict[str, Any]]:
        return self._summary

    def close(self) -> None:
        self.data = None

    def execute(
        self,
        operation: str,
        parameters: Any = None,
        settings: dict[str, Any] | None = None,
        query_formats: dict[str, str] | None = None,
        *,
        pyformat_encoded: bool = True,
    ) -> None:
        if pyformat_encoded and not parameters and isinstance(operation, str):
            # Per PEP 249 pyformat paramstyle, callers (e.g. SQLAlchemy) escape
            # literal percent signs as %% in operation strings.  When there are
            # parameters, Python's % operator in finalize_query handles the
            # unescaping automatically.  When there are no parameters,
            # finalize_query short-circuits, so we must unescape here.
            operation = operation.replace("%%", "%")
        query_result = self.client.query(operation, parameters, settings=settings, query_formats=query_formats)
        self.data = query_result.result_set
        self._rowcount = len(self.data)
        self._summary.append(query_result.summary)

        # Need to reset cursor _ix after performing an execute
        self._ix = 0
        self.names = []
        self.types = []

        if query_result.column_names:
            self.names = query_result.column_names
            self.types = [x.name for x in query_result.column_types]
        elif self.data:
            self.names = [f"col_{x}" for x in range(len(self.data[0]))]
            self.types = [x.__class__ for x in self.data[0]]
        else:
            stripped = operation.strip().rstrip(";").strip()
            if _leading_keyword(stripped) in ("SELECT", "WITH"):
                # Introspection re-query carries the same settings/formats so the derived column shape matches.
                try:
                    meta_result = self.client.query(
                        f"SELECT * FROM ({stripped}) LIMIT 0",
                        parameters,
                        settings=settings,
                        query_formats=query_formats,
                    )
                except DatabaseError:
                    logger.debug("DB-API cursor metadata probe failed; leaving description empty", exc_info=True)
                    return
                if meta_result.column_names:
                    self.names = meta_result.column_names
                    self.types = [x.name for x in meta_result.column_types]

    def _try_bulk_insert(self, operation: str, data: Any, settings: dict[str, Any] | None = None) -> bool:
        match = insert_re.match(remove_sql_comments(operation))
        if not match:
            return False
        temp = match.group(1)
        table_end = min(temp.find(" "), temp.find("("))
        table = temp[:table_end].strip()
        temp = temp[table_end:].strip()
        if temp[0] == "(":
            _, op_columns, temp = parse_callable(temp)
        else:
            op_columns = None
        if "VALUES" not in temp.upper():
            return False
        if not isinstance(data, Sequence) or len(data) == 0:
            return False
        if "%s" in temp or "%(" in temp:
            # Pyformat placeholders mean identifiers carry %% for literal percent
            # signs. Server-side {name:Type} statements keep raw percents.
            table = table.replace("%%", "%")
            if op_columns:
                op_columns = tuple(str(x).replace("%%", "%") for x in op_columns)
        first_row = data[0]
        col_names: list[str] | str
        data_values: Sequence[Sequence[Any]]
        if isinstance(first_row, Mapping):
            col_names = [str(k) for k in first_row.keys()]
            if op_columns and {unescape_identifier(str(x)) for x in op_columns} != set(col_names):
                return False  # Data sent in doesn't match the columns in the insert statement
            data_values = [list(row.values()) for row in data]
        elif isinstance(first_row, Sequence) and not isinstance(first_row, (str, bytes)):
            # PEP 249 also allows rows as sequences; take column names from the
            # insert statement if present, otherwise insert into all columns
            col_names = [unescape_identifier(str(x)) for x in op_columns] if op_columns else "*"
            data_values = data
        else:
            return False
        insert_summary = self.client.insert(table, data_values, col_names, settings=settings)
        self.data = []
        self._rowcount = insert_summary.written_rows
        self._ix = 0
        self._summary.append(insert_summary.summary)
        return True

    def executemany(
        self,
        operation: str,
        parameters: Any,
        settings: dict[str, Any] | None = None,
        query_formats: dict[str, str] | None = None,
    ) -> None:
        self.names = []
        self.types = []
        if not parameters or self._try_bulk_insert(operation, parameters, settings):
            return
        self.data = []
        try:
            for param_row in parameters:
                query_result = self.client.query(operation, param_row, settings=settings, query_formats=query_formats)
                self.data.extend(query_result.result_set)
                if self.names or self.types:
                    if query_result.column_names != self.names:
                        logger.warning(
                            "Inconsistent column names %s : %s for operation %s in cursor executemany",
                            self.names,
                            query_result.column_names,
                            operation,
                        )
                else:
                    self.names = query_result.column_names
                    self.types = query_result.column_types
                self._summary.append(query_result.summary)
        except TypeError as ex:
            raise ProgrammingError(f"Invalid parameters {parameters} passed to cursor executemany") from ex
        self._rowcount = len(self.data)

        # Need to reset cursor _ix after performing an execute
        self._ix = 0

    def fetchall(self) -> Sequence:
        self.check_valid()
        data = cast(Sequence, self.data)
        ret = data[self._ix :]
        self._ix = self._rowcount
        return ret

    def fetchone(self) -> Any:
        self.check_valid()
        if self._ix >= self._rowcount:
            return None
        data = cast(Sequence, self.data)
        val = data[self._ix]
        self._ix += 1
        return val

    def fetchmany(self, size: int = -1) -> Sequence:
        self.check_valid()
        data = cast(Sequence, self.data)

        if size < 0:
            # Fetch all remaining rows
            size = self._rowcount - self._ix
        elif size == 0:
            # Return empty list for size=0
            return []

        end = min(self._ix + size, self._rowcount)
        ret = data[self._ix : end]
        self._ix = end
        return ret

    def nextset(self) -> None:
        raise NotImplementedError

    def callproc(self, *args, **kwargs) -> None:
        raise NotImplementedError
