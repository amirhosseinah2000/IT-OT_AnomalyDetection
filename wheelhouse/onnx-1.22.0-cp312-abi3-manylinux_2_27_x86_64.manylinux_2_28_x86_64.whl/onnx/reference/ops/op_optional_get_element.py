# Copyright (c) ONNX Project Contributors

# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from onnx.reference.op_run import OpRun


class OptionalGetElement(OpRun):
    def _run(self, x):
        if x is None:
            raise ValueError("The requested optional input has no value.")
        return (x,)
